//
//  MyProductListScreen.swift
//  SmartShop
//
//  Created by Mohammad Azam on 10/15/24.
//

import SwiftUI

struct MyProductListScreen: View {
    
    @State private var isPresented: Bool = false
    
    var body: some View {
        Text("My Product List Screen")
            .toolbar(content: {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add Product") {
                        isPresented = true
                    }
                }
            }).sheet(isPresented: $isPresented, content: {
                NavigationStack {
                    AddProductScreen()
                }
            })
    }
}

#Preview {
    NavigationStack {
        MyProductListScreen()
    }
}

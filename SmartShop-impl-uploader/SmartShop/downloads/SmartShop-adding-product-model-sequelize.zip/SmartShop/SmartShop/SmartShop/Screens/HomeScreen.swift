//
//  HomeScreen.swift
//  SmartShop
//
//  Created by Mohammad Azam on 10/9/24.
//

import SwiftUI

enum AppScreen: Hashable, Identifiable, CaseIterable {
    case home
    case myProducts
    case cart
    case profile
    
    var id: AppScreen { self }
}

extension AppScreen {
    
    @ViewBuilder
    var label: some View {
        switch self {
            case .home:
                Label("Home", systemImage: "heart")
            case .myProducts:
                Label("My Products", systemImage: "star")
            case .cart:
                Label("Cart", systemImage: "cart")
            case .profile:
                Label("Profile", systemImage: "person.fill")
        }
    }
    
    @ViewBuilder
    var destination: some View {
        switch self {
            case .home:
                Text("Home")
            case .myProducts:
                NavigationStack {
                    Text("My Products")
                        .requiresAuthentication()
                }
            case .cart:
                NavigationStack {
                    Text("Cart")
                        .requiresAuthentication()
                }
            case .profile:
                NavigationStack {
                    ProfileScreen()
                        .requiresAuthentication()
                }
        }
    }
    
}

struct HomeScreen: View {
    
    @State var selection: AppScreen?
    
    var body: some View {
        TabView(selection: $selection) {
            ForEach(AppScreen.allCases) { screen in
                screen.destination
                    .tag(screen as AppScreen?)
                    .tabItem { screen.label }
            }
        }
    }
}

#Preview {
    HomeScreen()
}
